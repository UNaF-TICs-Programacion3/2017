﻿Public Class Frm_HostRentable

    Private Sub Frm_HostRentable_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Se puede asignar una lista de objetos directamente a la propiedad DataSource
        'Clientes as List(Of Cliente)
        'DataGridView1.DataSource = Clientes
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FrmAbrirNuevoTicket.ShowDialog()
    End Sub

End Class
