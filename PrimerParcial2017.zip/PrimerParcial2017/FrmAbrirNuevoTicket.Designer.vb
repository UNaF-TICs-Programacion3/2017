﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAbrirNuevoTicket
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CboCliente = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CboDepartamento = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtAsunto = New System.Windows.Forms.TextBox()
        Me.CboPrioridad = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtMensaje = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BtnAceptar = New System.Windows.Forms.Button()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.LblFecha = New System.Windows.Forms.Label()
        Me.LblFechaAlta = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'CboCliente
        '
        Me.CboCliente.FormattingEnabled = True
        Me.CboCliente.Location = New System.Drawing.Point(86, 78)
        Me.CboCliente.Name = "CboCliente"
        Me.CboCliente.Size = New System.Drawing.Size(322, 21)
        Me.CboCliente.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 81)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Cliente"
        '
        'CboDepartamento
        '
        Me.CboDepartamento.FormattingEnabled = True
        Me.CboDepartamento.Location = New System.Drawing.Point(86, 105)
        Me.CboDepartamento.Name = "CboDepartamento"
        Me.CboDepartamento.Size = New System.Drawing.Size(185, 21)
        Me.CboDepartamento.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Departamento"
        '
        'TxtAsunto
        '
        Me.TxtAsunto.Location = New System.Drawing.Point(86, 159)
        Me.TxtAsunto.Name = "TxtAsunto"
        Me.TxtAsunto.Size = New System.Drawing.Size(420, 20)
        Me.TxtAsunto.TabIndex = 4
        '
        'CboPrioridad
        '
        Me.CboPrioridad.FormattingEnabled = True
        Me.CboPrioridad.Items.AddRange(New Object() {"Baja", "Media", "Alta"})
        Me.CboPrioridad.Location = New System.Drawing.Point(86, 132)
        Me.CboPrioridad.Name = "CboPrioridad"
        Me.CboPrioridad.Size = New System.Drawing.Size(121, 21)
        Me.CboPrioridad.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 135)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Prioridad"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(41, 162)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Asunto"
        '
        'TxtMensaje
        '
        Me.TxtMensaje.Location = New System.Drawing.Point(86, 188)
        Me.TxtMensaje.Multiline = True
        Me.TxtMensaje.Name = "TxtMensaje"
        Me.TxtMensaje.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TxtMensaje.Size = New System.Drawing.Size(419, 197)
        Me.TxtMensaje.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(34, 188)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Mensaje"
        '
        'BtnAceptar
        '
        Me.BtnAceptar.Location = New System.Drawing.Point(437, 402)
        Me.BtnAceptar.Name = "BtnAceptar"
        Me.BtnAceptar.Size = New System.Drawing.Size(75, 23)
        Me.BtnAceptar.TabIndex = 10
        Me.BtnAceptar.Text = "Aceptar"
        Me.BtnAceptar.UseVisualStyleBackColor = True
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(356, 402)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 11
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'LblFecha
        '
        Me.LblFecha.AutoSize = True
        Me.LblFecha.Location = New System.Drawing.Point(291, 53)
        Me.LblFecha.Name = "LblFecha"
        Me.LblFecha.Size = New System.Drawing.Size(61, 13)
        Me.LblFecha.TabIndex = 12
        Me.LblFecha.Text = "Fecha Alta:"
        '
        'LblFechaAlta
        '
        Me.LblFechaAlta.AutoSize = True
        Me.LblFechaAlta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFechaAlta.Location = New System.Drawing.Point(355, 53)
        Me.LblFechaAlta.Name = "LblFechaAlta"
        Me.LblFechaAlta.Size = New System.Drawing.Size(157, 13)
        Me.LblFechaAlta.TabIndex = 13
        Me.LblFechaAlta.Text = "23/10/2017 11:54:10 a.m."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(5, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(321, 39)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Abrir Nuevo Ticket"
        '
        'FrmAbrirNuevoTicket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(524, 431)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.LblFechaAlta)
        Me.Controls.Add(Me.LblFecha)
        Me.Controls.Add(Me.BtnCancelar)
        Me.Controls.Add(Me.BtnAceptar)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TxtMensaje)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CboPrioridad)
        Me.Controls.Add(Me.TxtAsunto)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CboDepartamento)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CboCliente)
        Me.Name = "FrmAbrirNuevoTicket"
        Me.Text = "FrmAbrirNuevoTicket"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CboCliente As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CboDepartamento As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtAsunto As TextBox
    Friend WithEvents CboPrioridad As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TxtMensaje As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents BtnAceptar As Button
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents LblFecha As Label
    Friend WithEvents LblFechaAlta As Label
    Friend WithEvents Label6 As Label
End Class
