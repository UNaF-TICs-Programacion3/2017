﻿Public Class FrmReserva
    Private Sub BtnNuevaReserva_Click(sender As Object, e As EventArgs) Handles BtnNuevaReserva.Click
        FrmNuevaReserva.ShowDialog()
    End Sub

    Private Sub BtnVerDetalle_Click(sender As Object, e As EventArgs) Handles BtnVerDetalle.Click
        'DateDiff()
        MsgBox("Aquí debe ir el detalle de la reserva seleccionada.", vbInformation, "Hotel Madison -Detalle de la Reserva")
    End Sub
End Class
