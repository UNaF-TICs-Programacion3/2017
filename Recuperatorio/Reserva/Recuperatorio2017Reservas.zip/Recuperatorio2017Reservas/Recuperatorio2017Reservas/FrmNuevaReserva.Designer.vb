﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmNuevaReserva
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.LblFechaIngreso = New System.Windows.Forms.Label()
        Me.LblFechaEgreso = New System.Windows.Forms.Label()
        Me.TxtNombreCliente = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtCantidadMenores = New System.Windows.Forms.TextBox()
        Me.TxtCantidadAdultos = New System.Windows.Forms.TextBox()
        Me.LblNombreCliente = New System.Windows.Forms.Label()
        Me.LblCantidadAdultos = New System.Windows.Forms.Label()
        Me.LblCantidadMenores = New System.Windows.Forms.Label()
        Me.BtnAceptar = New System.Windows.Forms.Button()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.LblTipoHabitacion = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(147, 86)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(105, 22)
        Me.DateTimePicker1.TabIndex = 0
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker2.Location = New System.Drawing.Point(147, 114)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(107, 22)
        Me.DateTimePicker2.TabIndex = 1
        '
        'LblFechaIngreso
        '
        Me.LblFechaIngreso.AutoSize = True
        Me.LblFechaIngreso.Location = New System.Drawing.Point(43, 87)
        Me.LblFechaIngreso.Name = "LblFechaIngreso"
        Me.LblFechaIngreso.Size = New System.Drawing.Size(98, 17)
        Me.LblFechaIngreso.TabIndex = 2
        Me.LblFechaIngreso.Text = "Fecha Ingreso"
        '
        'LblFechaEgreso
        '
        Me.LblFechaEgreso.AutoSize = True
        Me.LblFechaEgreso.Location = New System.Drawing.Point(45, 115)
        Me.LblFechaEgreso.Name = "LblFechaEgreso"
        Me.LblFechaEgreso.Size = New System.Drawing.Size(96, 17)
        Me.LblFechaEgreso.TabIndex = 3
        Me.LblFechaEgreso.Text = "Fecha Egreso"
        '
        'TxtNombreCliente
        '
        Me.TxtNombreCliente.Location = New System.Drawing.Point(147, 142)
        Me.TxtNombreCliente.Name = "TxtNombreCliente"
        Me.TxtNombreCliente.Size = New System.Drawing.Size(324, 22)
        Me.TxtNombreCliente.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(44, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(305, 46)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Nueva Reserva"
        '
        'TxtCantidadMenores
        '
        Me.TxtCantidadMenores.Location = New System.Drawing.Point(147, 228)
        Me.TxtCantidadMenores.Name = "TxtCantidadMenores"
        Me.TxtCantidadMenores.Size = New System.Drawing.Size(52, 22)
        Me.TxtCantidadMenores.TabIndex = 6
        '
        'TxtCantidadAdultos
        '
        Me.TxtCantidadAdultos.Location = New System.Drawing.Point(147, 200)
        Me.TxtCantidadAdultos.Name = "TxtCantidadAdultos"
        Me.TxtCantidadAdultos.Size = New System.Drawing.Size(52, 22)
        Me.TxtCantidadAdultos.TabIndex = 6
        '
        'LblNombreCliente
        '
        Me.LblNombreCliente.AutoSize = True
        Me.LblNombreCliente.Location = New System.Drawing.Point(90, 143)
        Me.LblNombreCliente.Name = "LblNombreCliente"
        Me.LblNombreCliente.Size = New System.Drawing.Size(51, 17)
        Me.LblNombreCliente.TabIndex = 7
        Me.LblNombreCliente.Text = "Cliente"
        '
        'LblCantidadAdultos
        '
        Me.LblCantidadAdultos.AutoSize = True
        Me.LblCantidadAdultos.Location = New System.Drawing.Point(49, 203)
        Me.LblCantidadAdultos.Name = "LblCantidadAdultos"
        Me.LblCantidadAdultos.Size = New System.Drawing.Size(92, 17)
        Me.LblCantidadAdultos.TabIndex = 7
        Me.LblCantidadAdultos.Text = "Cant. Adultos"
        '
        'LblCantidadMenores
        '
        Me.LblCantidadMenores.AutoSize = True
        Me.LblCantidadMenores.Location = New System.Drawing.Point(41, 230)
        Me.LblCantidadMenores.Name = "LblCantidadMenores"
        Me.LblCantidadMenores.Size = New System.Drawing.Size(100, 17)
        Me.LblCantidadMenores.TabIndex = 7
        Me.LblCantidadMenores.Text = "Cant. Menores"
        '
        'BtnAceptar
        '
        Me.BtnAceptar.Location = New System.Drawing.Point(364, 253)
        Me.BtnAceptar.Name = "BtnAceptar"
        Me.BtnAceptar.Size = New System.Drawing.Size(75, 23)
        Me.BtnAceptar.TabIndex = 8
        Me.BtnAceptar.Text = "Aceptar"
        Me.BtnAceptar.UseVisualStyleBackColor = True
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(445, 253)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 8
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(147, 170)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(292, 24)
        Me.ComboBox1.TabIndex = 9
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(147, 170)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(292, 24)
        Me.ComboBox2.TabIndex = 9
        '
        'LblTipoHabitacion
        '
        Me.LblTipoHabitacion.AutoSize = True
        Me.LblTipoHabitacion.Location = New System.Drawing.Point(34, 172)
        Me.LblTipoHabitacion.Name = "LblTipoHabitacion"
        Me.LblTipoHabitacion.Size = New System.Drawing.Size(107, 17)
        Me.LblTipoHabitacion.TabIndex = 7
        Me.LblTipoHabitacion.Text = "Tipo Habitación"
        '
        'FrmNuevaReserva
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(559, 307)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.BtnCancelar)
        Me.Controls.Add(Me.BtnAceptar)
        Me.Controls.Add(Me.LblTipoHabitacion)
        Me.Controls.Add(Me.LblCantidadMenores)
        Me.Controls.Add(Me.LblCantidadAdultos)
        Me.Controls.Add(Me.LblNombreCliente)
        Me.Controls.Add(Me.TxtCantidadAdultos)
        Me.Controls.Add(Me.TxtCantidadMenores)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtNombreCliente)
        Me.Controls.Add(Me.LblFechaEgreso)
        Me.Controls.Add(Me.LblFechaIngreso)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Name = "FrmNuevaReserva"
        Me.Text = "Hotel Madison - Nueva Reserva"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents DateTimePicker2 As DateTimePicker
    Friend WithEvents LblFechaIngreso As Label
    Friend WithEvents LblFechaEgreso As Label
    Friend WithEvents TxtNombreCliente As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtCantidadMenores As TextBox
    Friend WithEvents TxtCantidadAdultos As TextBox
    Friend WithEvents LblNombreCliente As Label
    Friend WithEvents LblCantidadAdultos As Label
    Friend WithEvents LblCantidadMenores As Label
    Friend WithEvents BtnAceptar As Button
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents LblTipoHabitacion As Label
End Class
